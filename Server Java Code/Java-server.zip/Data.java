package com.project.data;

import com.mongodb.MongoClient;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;

import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Request;
import javax.ws.rs.core.UriInfo;
import org.bson.Document;


@Path("/data")
public class Data {

	@Context
	UriInfo uriInfo;
	@Context
	Request request;

	private String name;
	public Integer id = 0;

	// adding a test document
	public Data() {
		name = "test";
		
	}

	@GET
	public String printName() {
		return name;
	}

	@GET
	@Produces(MediaType.TEXT_XML)
	public String sayXML() {
		MongoClient mc = new MongoClient("localhost", 27017);
		MongoDatabase database = mc.getDatabase("data");
		MongoCollection<Document> coll = database.getCollection("files");
		Document doc = new Document();
		doc.append("id", JsonObject.id2);
		Document doc2 = coll.find(doc).first();	
		String s = "Battery 1: " + doc2.get("soc1") + ".     " +  System.lineSeparator() +
				"Battery 2: " + doc2.get("soc2") + ".     " +  System.lineSeparator() +
				"Battery 3: " + doc2.get("soc3") + ".     " +  System.lineSeparator() +
				"Temperature: " + doc2.get("temp") + ".     " + System.lineSeparator()	+ 
				"Humidity: " + doc2.get("humid") + ".     "  + System.lineSeparator() +
				"Data/Time: " + doc2.get("time") + ".     "  + System.lineSeparator();
		
		mc.close();
		 
		 return s;
	}

	@GET
	@Produces(MediaType.TEXT_HTML)
	public String sayHtml() {
		MongoClient mc = new MongoClient("localhost", 27017);
		MongoDatabase database = mc.getDatabase("data");
		MongoCollection<Document> coll = database.getCollection("files");
		Document doc = new Document();
		doc.append("id", JsonObject.id2);
		Document doc2 = coll.find(doc).first();	
		String s = "Battery 1: " + doc2.get("soc1") + ".     " +  System.lineSeparator() +
				"Battery 2: " + doc2.get("soc2") + ".     " +  System.lineSeparator() +
				"Battery 3: " + doc2.get("soc3") + ".     " +  System.lineSeparator() +
				"Temperature: " + doc2.get("temp") + ".     " + System.lineSeparator()	+ 
				"Humidity: " + doc2.get("humid") + ".     "  + System.lineSeparator() +
				"Data/Time: " + doc2.get("time") + ".     "  + System.lineSeparator();
		
		mc.close();
		 
		 return s;
	}

	@GET
	@Produces(MediaType.APPLICATION_JSON)
	public String sayJSON() {
		return "json";
	}
	
	@POST
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.TEXT_PLAIN)
	public void add(JsonObject jo) {
		MongoClient mc = new MongoClient("localhost", 27017);
		MongoDatabase database = mc.getDatabase("data");
		MongoCollection<Document> coll = database.getCollection("files");
		Document doc = new Document();
		doc.put("soc1", jo.soc1);
		doc.put("soc2", jo.soc2);
		doc.put("soc3", jo.soc3);
		doc.put("temp", jo.temp);
		doc.put("humid", jo.humid);
		doc.put("time", jo.time);
		doc.put("id", JsonObject.setId());
		
		coll.insertOne(doc);
		
		mc.close();
		
	}
	
	
}
