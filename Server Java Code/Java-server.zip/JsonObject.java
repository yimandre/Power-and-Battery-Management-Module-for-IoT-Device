package com.project.data;

import javax.xml.bind.annotation.XmlRootElement;


@XmlRootElement
public class JsonObject {

	
	 public String soc1;
	 public String soc2;
	 public String soc3;
	 public String temp;
	 public String humid;
	 public String time;
	 public static Integer id2 = 0;
	
	public JsonObject() {
    }
	
	JsonObject(String soc1, String soc2, String soc3, String temp, String humid, String time, int i) {
		this.soc1 = soc1;
		this.soc2 = soc2;
		this.soc3 = soc3;
		this.temp = temp;
		this.humid = humid;
		this.time = time;
		id2 = i;
	}
	
	public String getSoc1() {
		return soc1;
	}
	
	public String getSoc2() {
		return soc2;
	}
   
	public String getSoc3() {
		return soc3;
	}
	
	public String getTemp() {
		return temp;
	}
    
	public String getHumid() {
		return humid;
	}
   
	public String getTime() {
		return time;
	}
   
	public int getId() {
		return id2;
	}
	public static int setId() {
		return ++id2;
	}
}

